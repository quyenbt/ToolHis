/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

/**
 *
 * @author soft1
 */
public class HoSoKCB {
    public String sRow1[];
    public double dt_thuoc;
    public double dt_vtyt;
    public double dt_tongchi;
    public double tienXN=0;
    public double tienCDHA=0;
    public boolean hosokhongloi;
}
