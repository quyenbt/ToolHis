/**
 * Feb 10, 2016
 */
package org.byt.exception;

/**
 * @author admin
 *
 */
public class NodeException extends Exception{
	public NodeException(String message){
		super(message);
	}
}
