/**
 * Feb 10, 2016
 */
package org.byt.exception;

/**
 * @author admin
 *
 */
public class MaLienKetException extends Exception{
	public MaLienKetException(String message){
		super(message);
	}
}
