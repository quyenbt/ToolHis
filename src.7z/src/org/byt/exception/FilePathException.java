/**
 * Feb 10, 2016
 */
package org.byt.exception;

/**
 * @author admin
 *
 */
public class FilePathException extends Exception{
	public FilePathException(String message){
		super(message);
	}
}
